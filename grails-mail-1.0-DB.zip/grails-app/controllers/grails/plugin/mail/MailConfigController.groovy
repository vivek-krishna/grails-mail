package grails.plugin.mail

class MailConfigController {

    static allowedMethods = [save: "POST", update: "POST", delete: "POST"]

    def index = {
        redirect(action: "list", params: params)
    }

    def list = {
        params.max = Math.min(params.max ? params.int('max') : 10, 100)
        [mailConfigInstanceList: MailConfig.list(params), mailConfigInstanceTotal: MailConfig.count()]
    }

    def create = {
        def mailConfigInstance = new MailConfig()
        mailConfigInstance.properties = params
        return [mailConfigInstance: mailConfigInstance]
    }

    def save = {
        def mailConfigInstance = new MailConfig(params)
        if (mailConfigInstance.save(flush: true)) {
            flash.message = "${message(code: 'default.created.message', args: [message(code: 'mailConfig.label', default: 'MailConfig'), mailConfigInstance.id])}"
            redirect(action: "show", id: mailConfigInstance.id)
        }
        else {
            render(view: "create", model: [mailConfigInstance: mailConfigInstance])
        }
    }

    def show = {
        def mailConfigInstance = MailConfig.get(params.id)
        if (!mailConfigInstance) {
            flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'mailConfig.label', default: 'MailConfig'), params.id])}"
            redirect(action: "list")
        }
        else {
            [mailConfigInstance: mailConfigInstance]
        }
    }

    def edit = {
        def mailConfigInstance = MailConfig.get(params.id)
        if (!mailConfigInstance) {
            flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'mailConfig.label', default: 'MailConfig'), params.id])}"
            redirect(action: "list")
        }
        else {
            return [mailConfigInstance: mailConfigInstance]
        }
    }

    def update = {
        def mailConfigInstance = MailConfig.get(params.id)
        if (mailConfigInstance) {
            if (params.version) {
                def version = params.version.toLong()
                if (mailConfigInstance.version > version) {
                    
                    mailConfigInstance.errors.rejectValue("version", "default.optimistic.locking.failure", [message(code: 'mailConfig.label', default: 'MailConfig')] as Object[], "Another user has updated this MailConfig while you were editing")
                    render(view: "edit", model: [mailConfigInstance: mailConfigInstance])
                    return
                }
            }
            mailConfigInstance.properties = params
            if (!mailConfigInstance.hasErrors() && mailConfigInstance.save(flush: true)) {
                flash.message = "${message(code: 'default.updated.message', args: [message(code: 'mailConfig.label', default: 'MailConfig'), mailConfigInstance.id])}"
                redirect(action: "show", id: mailConfigInstance.id)
            }
            else {
                render(view: "edit", model: [mailConfigInstance: mailConfigInstance])
            }
        }
        else {
            flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'mailConfig.label', default: 'MailConfig'), params.id])}"
            redirect(action: "list")
        }
    }

    def delete = {
        def mailConfigInstance = MailConfig.get(params.id)
        if (mailConfigInstance) {
            try {
                mailConfigInstance.delete(flush: true)
                flash.message = "${message(code: 'default.deleted.message', args: [message(code: 'mailConfig.label', default: 'MailConfig'), params.id])}"
                redirect(action: "list")
            }
            catch (org.springframework.dao.DataIntegrityViolationException e) {
                flash.message = "${message(code: 'default.not.deleted.message', args: [message(code: 'mailConfig.label', default: 'MailConfig'), params.id])}"
                redirect(action: "show", id: params.id)
            }
        }
        else {
            flash.message = "${message(code: 'default.not.found.message', args: [message(code: 'mailConfig.label', default: 'MailConfig'), params.id])}"
            redirect(action: "list")
        }
    }
}
