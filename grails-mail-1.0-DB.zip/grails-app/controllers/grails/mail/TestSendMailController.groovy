package grails.mail

class TestSendMailController {
    def mailService
    def index = {

        mailService.sendMail {
            multipart true
            from "svivekkris@gmail.com"
            to "svivekkrishna@gmail.com"
            subject "Test Configuration Based Emails"
            body "Testing DB driven email sending configuration"
            attachBytes "File.pdf", "application/pdf", new File("/home/vivek/scanned.pdf").bytes
        }
    }

    def mailSender

    def show = {
        println("Mail Sender" + mailSender.password)
    }
}
