package grails.plugin.mail

class MailConfig {
    String username
    String host
    Integer port
    String password
    String props
    static constraints = {
    }
}
